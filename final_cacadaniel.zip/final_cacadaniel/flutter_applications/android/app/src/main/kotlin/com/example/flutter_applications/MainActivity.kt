package com.example.flutter_applications

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
